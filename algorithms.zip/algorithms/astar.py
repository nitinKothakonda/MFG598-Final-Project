import numpy as np
import heapq
import networkx as nx
import matplotlib.pyplot as plt


def heuristic(a, b):
    # Euclidean distance heuristic
    return np.linalg.norm(np.array(a) - np.array(b))

def astar(grid, start, goal):
    rows, cols = grid.shape
    open_list = []
    heapq.heappush(open_list, (0, start))  # Push the start point into the open list
    came_from = {}
    g_score = {start: 0}

    while open_list:
        _, current = heapq.heappop(open_list)  # Get the node with the lowest f-score

        if current == goal:
            # Reconstruct the path
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path = path[::-1]  # Reverse the path to go from start to goal
            return path

        # Check all 4 directions (up, down, left, right)
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            neighbor = (current[0] + dx, current[1] + dy)

            # Ensure the neighbor is within grid bounds and not an obstacle (value 1)
            if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols and grid[neighbor] == 0:
                temp_g_score = g_score[current] + 1  # Increment the cost by 1
                if neighbor not in g_score or temp_g_score < g_score[neighbor]:
                    g_score[neighbor] = temp_g_score
                    f_score = temp_g_score + heuristic(neighbor, goal)
                    heapq.heappush(open_list, (f_score, neighbor))
                    came_from[neighbor] = current

    return None  # No path found


