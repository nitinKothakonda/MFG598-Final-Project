import sqlite3

conn = sqlite3.connect("path_planning.db")
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS paths (id INTEGER PRIMARY KEY, start TEXT, goal TEXT, path TEXT)")

def save_path(start, goal, path):
    path_str = str(path)
    c.execute("INSERT INTO paths (start, goal, path) VALUES (?, ?, ?)", (str(start), str(goal), path_str))
    conn.commit()
