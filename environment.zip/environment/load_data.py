import numpy as np

def load_grid(filename):
    """Load grid from a CSV file."""
    # Assuming your CSV file contains the grid data where 1 represents obstacles and 0 is free space
    return np.genfromtxt(filename, delimiter=',')
