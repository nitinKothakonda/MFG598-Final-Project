import plotly.graph_objects as go

def visualize(grid, path, start=None, goal=None):
    fig = go.Figure()

    #(0 = free space, 1 = obstacle)
    fig.add_trace(go.Heatmap(
        z=grid,
        colorscale='Blues',  # Blue color for obstacles
        colorbar=dict(title="Grid Values"),
        showscale=False,
        zmin=0, zmax=1,
        hoverinfo='none'
    ))

    # Plot the start and goal points
    if start:
        fig.add_trace(go.Scatter(
            x=[start[1]],
            y=[start[0]],
            mode='markers',
            marker=dict(color='green', size=15),
            name='Start'
        ))

    if goal:
        fig.add_trace(go.Scatter(
            x=[goal[1]],
            y=[goal[0]],
            mode='markers',
            marker=dict(color='red', size=15),
            name='Goal'
        ))

    # Plot the path as a red line (connecting the red dots) only if the path exists
    if path:
        path_x = [p[1] for p in path]
        path_y = [p[0] for p in path]
        fig.add_trace(go.Scatter(
            x=path_x,
            y=path_y,
            mode='lines+markers',  # Path as a continuous line
            marker=dict(color='red', size=8),
            line=dict(color='red', width=3),
            name='Path'
        ))

        # Create frames for robot movement animation (only robot position changes)
        frames = []
        for i in range(len(path)):
            frame = go.Frame(
                data=[
                    go.Scatter(
                        x=[path[i][1]],  
                        y=[path[i][0]],  
                        mode='markers',
                        marker=dict(color='purple', size=15),
                        name='Robot'
                    )
                ],
                name=f"Frame {i}"
            )
            frames.append(frame)

        fig.frames = frames  

        # Add Play/Pause buttons for animation control
        fig.update_layout(
            updatemenus=[{
                'buttons': [
                    {
                        'args': [None, {'frame': {'duration': 500, 'redraw': True}, 'fromcurrent': True}],
                        'label': 'Play',
                        'method': 'animate'
                    },
                    {
                        'args': [[None], {'frame': {'duration': 0, 'redraw': True}, 'mode': 'immediate', 'transition': {'duration': 0}}],
                        'label': 'Pause',
                        'method': 'animate'
                    }
                ],
                'direction': 'left',
                'pad': {'r': 10, 't': 87},
                'showactive': False,
                'type': 'buttons',
                'x': 0.1,
                'xanchor': 'right',
                'y': 0,
                'yanchor': 'top'
            }]
        )

    return fig
